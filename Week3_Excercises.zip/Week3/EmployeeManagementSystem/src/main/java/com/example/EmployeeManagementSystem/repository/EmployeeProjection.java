package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.model.Employee;
import org.springframework.data.rest.core.config.Projection;

@Projection(name = "employeeProjection", types = { Employee.class })
public interface EmployeeProjection {

    Long getId();
    String getName();
    String getEmail(); // Directly exposes the email field
    String getDepartmentName(); // Custom method to get department name
}