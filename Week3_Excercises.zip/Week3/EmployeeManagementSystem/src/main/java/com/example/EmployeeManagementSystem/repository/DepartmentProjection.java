package com.example.EmployeeManagementSystem.repository;



import org.springframework.data.rest.core.config.Projection;

import com.example.EmployeeManagementSystem.model.*;

@Projection(name = "departmentProjection", types = { Department.class })
public interface DepartmentProjection {

    Long getId();

    String getName();
}

