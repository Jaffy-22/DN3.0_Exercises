package com.example.EmployeeManagementSystem.repository;

import java.awt.print.Pageable;
import java.util.List;
import java.util.Optional;

import org.hibernate.query.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.EmployeeManagementSystem.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Long> {
	
	Optional<Employee> findByEmail(String email);
	
	List<Employee> findByDepartmentId(Long departmentId);
	
	long countByDepartmentId(Long departmentId);
	
	
    List<Employee> findByNameContaining(String name);


    List<Employee> findByDepartmentName(String departmentName);
    
    Page findByDepartmentId(Long departmentId, Pageable pageable);

    Page findByNameContaining(String name, Pageable pageable);

    Page findAll(Pageable pageable);
}
