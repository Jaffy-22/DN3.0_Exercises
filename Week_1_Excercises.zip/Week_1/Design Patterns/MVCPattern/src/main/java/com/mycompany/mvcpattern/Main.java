/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mvcpattern;

/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args) {
        Student student = new Student("John Doe", 1, "A");
        StudentView studentView = new StudentView();
        StudentController studentController = new StudentController(student, studentView);
        studentController.updateView();
        studentController.setStudentName("Jane Smith");
        studentController.setStudentId(2);
        studentController.setStudentGrade("B");
        studentController.updateView();
    }
}
