/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stratergypattern;

/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args) {
        PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9876-5432");
        PaymentStrategy payPal = new PayPalPayment("user@example.com");
        PaymentContext context = new PaymentContext(creditCard);
        context.executePayment(100.00);
        context = new PaymentContext(payPal);
        context.executePayment(200.00);
    }
}
