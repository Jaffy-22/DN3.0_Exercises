/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dependencyinjection;

/**
 *
 * @author Jaffy
 */
public class CustomerRepositoryImpl implements CustomerRepository {

    @Override
    public String findCustomerById(int id) {
        // Simulate fetching customer data from a database
        return "Customer with ID: " + id;
    }
}

