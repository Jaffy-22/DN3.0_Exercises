/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.adapterpattern;

/**
 *
 * @author Jaffy
 */
public class PaymentGatewayA {
    public void payViaGatewayA(double amount) {
        System.out.println("Processing payment of $" + amount + " via Payment Gateway A.");
    }
}
