/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.adapterpattern;

/**
 *
 * @author Jaffy
 */
public class PaymentGatewayB {
    public void payViaGatewayB(double amount) {
        System.out.println("Processing payment of $" + amount + " via Payment Gateway B.");
    }
}
