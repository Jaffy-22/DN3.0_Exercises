/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Jaffy
 */
public class EmployeeDetails {
    private Employee[] employees;
    private int count;

    public EmployeeDetails(int capacity) {
        employees = new Employee[capacity];
        count = 0;
    }

    public void addEmployee(int employeeId, String name, String position, double salary) {
        if (count < employees.length) {
            employees[count++] = new Employee(employeeId, name, position, salary);
        } else {
            System.out.println("Employee list is full. Cannot add more employees.");
        }
    }

    public void searchEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                System.out.println("Employee Found: " + employees[i]);
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                for (int j = i; j < count - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--count] = null; 
                System.out.println("Employee deleted.");
                return;
            }
        }
        System.out.println("Employee not found.");
    }
}
