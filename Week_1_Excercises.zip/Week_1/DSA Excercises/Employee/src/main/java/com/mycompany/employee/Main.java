/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args)
    {
        EmployeeDetails emp = new EmployeeDetails(10);

        emp.addEmployee(1, "Alice", "Manager", 75000);
        emp.addEmployee(2, "Bob", "Developer", 60000);
        emp.addEmployee(3, "Charlie", "Designer", 55000);
        emp.addEmployee(4, "Dave", "Tester", 50000);
        emp.addEmployee(5, "Eve", "Support", 45000);
        emp.traverseEmployees();
        emp.searchEmployee(3);
        emp.deleteEmployee(2);
        emp.traverseEmployees();
        }
 }
