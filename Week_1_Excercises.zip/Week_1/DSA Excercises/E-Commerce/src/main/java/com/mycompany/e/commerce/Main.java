/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;


/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args)
    {
        AddProduct prod = new AddProduct();
        prod.add(1, "Chair", "Furniture");
        prod.add(2, "Table", "Furniture");
        prod.add(3, "Laptop", "Electronics");
        prod.add(4, "Smartphone", "Electronics");
        prod.add(5, "Notebook", "Stationery");
        prod.add(6, "Pen", "Stationery");
        prod.add(7, "Shoes", "Footwear");
        prod.add(8, "T-shirt", "Clothing");
        prod.add(9, "Jeans", "Clothing");
        prod.add(10, "Blender", "Kitchen Appliances");
        prod.linearSearch(5);
        prod.linearSearch(11);
        prod.binarySearch(9);
        prod.binarySearch(23);
    }
}
