/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce;

import java.util.Scanner;

/**
 *
 * @author Jaffy
 */
public class AddProduct {
    public static Ecommerce[] arr = new Ecommerce[10];
    static int count = 0;

    public static void add(int productId, String productName, String category) {
        arr[count] = new Ecommerce(productId, productName, category);
        count++;
    }
    public static void linearSearch(int productId)
    {
       boolean isFound=false;
       for(int i=0;i<count;i++)
       {
           if(arr[i].getProductId()==productId)
           {
               System.out.println("Product Found: " + arr[i]);
               isFound=true;
               break;
           }  
       }
       if(!isFound)
           System.out.println("Not Found");
    }
    public static void binarySearch(int productId) {
        int left = 0, right = count - 1;
        boolean isFound = false;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid].getProductId() == productId) {
                System.out.println("Product Found: " + arr[mid]);
                isFound = true;
                break;
            }
            if (arr[mid].getProductId() < productId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        if (!isFound) {
            System.out.println("Not Found");
        }
    }
}
