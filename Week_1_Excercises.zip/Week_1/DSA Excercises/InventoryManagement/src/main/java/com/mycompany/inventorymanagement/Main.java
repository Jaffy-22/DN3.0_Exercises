/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventorymanagement;

import java.util.Scanner;

/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        InventoryManagement prod = new InventoryManagement();
        System.out.println("Welcome To Inventory Management");
        
        do{
        System.out.println("1.Add Product\n2.Update Product\n3.Delete Product\n4.Exit");
        System.out.print("Enter Your choice:");
        int choice = scan.nextInt();
        scan.nextLine(); 
        
        switch(choice)
        {
            case 1:
            {
                 System.out.println("Enter Product ID:");
                 String prodId = scan.nextLine();
                 System.out.println("Enter Product Name:");
                 String prodName = scan.nextLine();
                 System.out.println("Enter Quantity:");
                 int quantity = scan.nextInt();
                 System.out.println("Enter Price:");
                 int price = scan.nextInt();
                 prod.addProduct(prodId, prodName, quantity, price);
                 System.out.println("Product added successfully!");
                 break;
            }
            case 2:
            {
                System.out.println("Enter Product ID:");
                String prodId = scan.nextLine();
                prod.updateProduct(prodId);
                break;
            }
            case 3:
            {
                System.out.println("Enter Product ID:");
                String prodId = scan.nextLine();
                prod.deleteProduct(prodId);
                break;
            }
            case 4:
                break;
            default:
                break;
        }
        }while(true);
    }
}
