/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventorymanagement;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author Jaffy
 */
public class InventoryManagement {
    private String productId;
    private String productName;
    private int quantity;
    private int price;
    public static ArrayList<InventoryManagement> products = new ArrayList<>();
    public InventoryManagement()
    {
        super();
    }
    public InventoryManagement(String productId, String productName, int quantity,int price)
    {
        this.price=price;
        this.productId=productId;
        this.productName=productName;
        this.quantity=quantity;
    }
    public static void addProduct(String productId, String productName, int quantity,int price)
    {
        InventoryManagement prod = new InventoryManagement(productId,productName,quantity,price);
        products.add(prod);
    }
    public static void updateProduct(String productId)
    {
        Scanner scan= new Scanner(System.in);
        int choice =0;
        boolean isProductFound = false;
        for (InventoryManagement item : products) 
        {
            if(item.getProductId().equals(productId))
            {
                isProductFound=true;
                do{
                System.out.println("Choose The Option TO Update\n1.Quantity\n2.Price\n3Exit");
                choice = scan.nextInt();
                switch(choice)
                {
                    case 1:
                    {
                        System.out.println("Enter The New Quantity");
                        int newQuantity=scan.nextInt();
                        item.setQuantity(newQuantity);
                        break;
                    }
                    case 2:
                    {
                        System.out.println("Enter The New Price");
                        int newPrice=scan.nextInt();
                        item.setPrice(newPrice);
                        break;
                    }
                    case 3:
                        break;
                    default:
                        break;
                }
                }while(choice!=3);
                break;
            }
        }
        if(!isProductFound)
            System.out.println("Product Not Found");
    }
    public static void deleteProduct(String productId)
    {
        Scanner scan= new Scanner(System.in);
        int choice =0;
        boolean isProductFound = false; 
        Iterator<InventoryManagement> iterator = products.iterator();
        while(iterator.hasNext())
        {
            InventoryManagement item =iterator.next();
            if(item.getProductId().equals(productId))
            {
                isProductFound = true;
                iterator.remove();
                break;
            }
        }
        if (!isProductFound) {
            System.out.println("Product not found.");
        }
    }
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
}
