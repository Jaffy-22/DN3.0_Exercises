/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanagement;

/**
 *
 * @author Jaffy
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ManageBook {
    private ArrayList<Book> books;

    public ManageBook() {
        books = new ArrayList<>();
    }

    public void addBook(int bookId, String title, String author) {
        Book newBook = new Book(bookId, title, author);
        books.add(newBook);
    }

    public void linearSearch(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                System.out.println("Book Found: " + book);
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void binarySearch(String title) {
        // Ensure the list is sorted before binary search
        books.sort(Comparator.comparing(Book::getTitle));
        
        int low = 0;
        int high = books.size() - 1;
        
        while (low <= high) {
            int mid = (low + high) / 2;
            Book midBook = books.get(mid);
            int comparison = midBook.getTitle().compareToIgnoreCase(title);
            
            if (comparison == 0) {
                System.out.println("Book Found: " + midBook);
                return;
            } else if (comparison < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        System.out.println("Book not found.");
    }
}