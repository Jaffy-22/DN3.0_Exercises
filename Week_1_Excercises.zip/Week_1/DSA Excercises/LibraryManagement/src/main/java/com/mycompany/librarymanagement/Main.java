/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanagement;

/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args) {
        ManageBook book = new ManageBook();

        book.addBook(1, "The Catcher in the Rye", "J.D. Salinger");
        book.addBook(2, "To Kill a Mockingbird", "Harper Lee");
        book.addBook(3, "1984", "George Orwell");
        book.addBook(4, "The Great Gatsby", "F. Scott Fitzgerald");
        book.addBook(5, "Moby-Dick", "Herman Melville");
        book.linearSearch("1984");
        book.binarySearch("To Kill a Mockingbird");
        book.binarySearch("The Lord of the Rings");
    }
}
