/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sorting;

/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order(1, "Jaffy", 200.0),
            new Order(2, "Harsha", 150.0),
            new Order(3, "Hemalatha", 300.0),
            new Order(4, "Jayashrree", 100.0),
            new Order(5, "Buvi", 250.0)
        };

        BubbleSort.bubbleSort(orders);
        System.out.println("Orders sorted:");
        for (Order order : orders) {
            System.out.println(order);
        }

        orders = new Order[]{
            new Order(1, "Jaffy", 200.0),
            new Order(2, "Harsha", 150.0),
            new Order(3, "Hemalatha", 300.0),
            new Order(4, "Jayashrree", 100.0),
            new Order(5, "Buvi", 250.0)
        };

        QuickSort.quickSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders sorted:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}