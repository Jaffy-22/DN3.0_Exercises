package com.mycompany.mavenproject2;

import java.util.LinkedList;

public class ManageTasks {
    private LinkedList<TaskManagement> tasks;

    public ManageTasks() {
        tasks = new LinkedList<>();
    }

    public void addTask(int taskId, String taskName, String status) {
        TaskManagement newTask = new TaskManagement(taskId, taskName, status);
        tasks.add(newTask);
    }

    public void searchTask(int taskId) {
        for (TaskManagement task : tasks) {
            if (task.getTaskId() == taskId) {
                System.out.println("Task Found: " + task);
                return;
            }
        }
        System.out.println("Task not found.");
    }

    public void traverseTasks() {
        for (TaskManagement task : tasks) {
            System.out.println(task);
        }
    }

    public void deleteTask(int taskId) {
        for (TaskManagement task : tasks) {
            if (task.getTaskId() == taskId) {
                tasks.remove(task);
                System.out.println("Task deleted.");
                return;
            }
        }
        System.out.println("Task not found.");
    }
}
