/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject2;

/**
 *
 * @author Jaffy
 */
public class Main {
    public static void main(String[] args) {
        ManageTasks task = new ManageTasks();

        task.addTask(1, "Design Database", "Pending");
        task.addTask(2, "Develop Backend", "In Progress");
        task.addTask(3, "Design Frontend", "Pending");
        task.addTask(4, "Integrate Backend and Frontend", "Pending");
        task.addTask(5, "Test Application", "Pending");

        task.traverseTasks();
        task.searchTask(3);
        task.deleteTask(2);
        task.traverseTasks();
    }
}
